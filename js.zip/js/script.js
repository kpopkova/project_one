/*alert("it works!");

for(var i=10; i<=20; i++) {
console.log(i);
}

for (var  i=10; i<=20; i++){
	console.log(Math.pow(i,2))
}

var x = 10 + 11 + 12 + 13 + 14 + 15 + 16 + 17 + 18 + 19 + 20;
console.log(x);*/

function one() {
	var x1 = parseInt(document.getElementById('x1').value);
	var x2 = parseInt(document.getElementById('x2').value);
if (Number.isNaN(x1) || Number.isNaN(x2)){
		alert("В поля x1 и x2 должы быть введены числа");
		} 
else if (x1 == null || x2 == null) {
		alert("Поля x1 и x2 должны быть заполнены"); 
} 
else {
		var resultDiv = document.getElementById('result');
	resultDiv.innerHTML="";
		}
}


function clr() {
	document.getElementById('x1').value = '';
	document.getElementById('x2').value = '';
}

function two() {
	var resultDiv = document.getElementById('result');
	var choice = document.getElementsByName('r1');
	console.log(choice)
	
	var x1 = parseInt(document.getElementById('x1').value);
	var x2 = parseInt(document.getElementById('x2').value);
	
	 if (choice[0].checked) {
		 resultDiv.append( + ((x1 + x2) * (x2 - x1 + 1)) / 2); 
		 }
	 else if (choice[1].checked){
		 resultDiv.append( + x1 * x2); 
	 }
}